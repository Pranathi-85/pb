var express=require("express")
var bodyParser=require("body-parser")
var mongoose=require("mongoose")

const app=express()

app.use(bodyParser.json())
app.use(express.static('public'))
app.use(bodyParser.urlencoded({extended:true}))

mongoose.connect("mongodb+srv://pranathiyalla:prana85@cluster0.fnneo.mongodb.net/signup1")
var db=mongoose.connection
db.on('error',()=> console.log("Error in Connecting to Database"))
db.once('open',()=> console.log("Connected to Database"))

app.post("/Register",(req,res) => {
    var number= req.body.number
    var name =  req.body.name
    var branchname= req.body.branchname
    var mobileno = req.body.mobileno
    var email = req.body.email
    var password = req.body.password
    var confirmpassword = req.body.confirmpassword
   
    var data={
        "number":number,
        "name":name,
        "branchname":branchname,
        "mobileno":mobileno,
        "email":email,
        "password":password,
        "confirmpassword":confirmpassword
 }
    db.collection('Details').insertOne(data,(err,collection) => {
        if(err){
            throw err;
        }
         console.log("Record Inserted Succesfully")
    })
    return res.redirect('user login.html')
})
app.post("/Login", (req, res) => {
    var accountnumber = req.body.accountnumber;
    var password = req.body.password;

    db.collection('Details').findOne({accountnumber: accountnumber, password: password }, (err, user) => {
        if (err) {
            throw err;
        }
        if (user) {
            console.log("Login Successful");
            return res.redirect('index.html');  
        } else {
            console.log("Invalid Credentials");
            return res.redirect('user login.html'); 
        }
    });
});


app.get("/",(req,res) => {
    res.set({
        "Allow-acces-Allow-Origin":'*'
    })
    return res.redirect('usersignin.html')
}).listen(4001);

console.log("Listening on port 4001")
